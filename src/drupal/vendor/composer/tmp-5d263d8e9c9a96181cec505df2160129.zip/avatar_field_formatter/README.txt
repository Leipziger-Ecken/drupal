Avatar Field Formatter
